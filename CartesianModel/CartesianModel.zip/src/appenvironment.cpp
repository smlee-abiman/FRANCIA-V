#include "appenvironment.h"
#include <QDir>

const QString AppEnvironment::m_mainAppVersion = "1.6.9_25122501";
QString AppEnvironment::m_appDirPath;

AppEnvironment::AppEnvironment()
{
}

QString AppEnvironment::getSystemSettingAppDirPathNonRealTarget() {
    QString applicationPath = AppEnvironment::getApplicationFolderPath();
    QDir dir(applicationPath);
    dir.cdUp();
    dir.cdUp();
    dir.cd("bin");
    return dir.path();
};


